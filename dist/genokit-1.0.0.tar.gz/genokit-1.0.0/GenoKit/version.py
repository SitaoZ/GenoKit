# __version__ = '0.2.6'
# __date__ = "Sep 3, 2025"

__version__ = '1.0.0'
__date__ = "Aug 8, 2026"