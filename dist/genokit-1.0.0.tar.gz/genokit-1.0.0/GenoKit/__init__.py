# -*- coding: utf-8 -*-
import sys

"""GenoKit package."""
__version__ = "0.2.6"
__author__ = "Sitao Zhu"
__email__ = "zhusitao1990@163.com"
