# -*- coding: utf-8 -*-
import sys
import gffutils
import pandas as pd
from tqdm import tqdm
from Bio import SeqIO
from Bio.Seq import Seq

import numpy as np
import matplotlib.pyplot as plt
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.motifs import create, jaspar
from io import StringIO
import logomaker
import pandas as pd

